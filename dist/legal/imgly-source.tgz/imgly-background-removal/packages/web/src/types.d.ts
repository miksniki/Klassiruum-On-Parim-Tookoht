interface Navigator {
  gpu: any;
}
